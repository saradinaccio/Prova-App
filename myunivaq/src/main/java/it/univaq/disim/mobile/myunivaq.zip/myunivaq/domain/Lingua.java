package it.univaq.disim.mobile.myunivaq.domain;

public enum Lingua {

	ITA, ENG;
}

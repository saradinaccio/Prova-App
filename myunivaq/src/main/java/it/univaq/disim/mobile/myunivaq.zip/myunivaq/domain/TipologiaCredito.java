package it.univaq.disim.mobile.myunivaq.domain;

public enum TipologiaCredito implements java.io.Serializable {

	a,b,c,d,e,f;
}
